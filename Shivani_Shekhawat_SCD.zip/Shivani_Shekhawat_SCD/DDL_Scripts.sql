 /*DDL Scripts SCD Assignment - Shivani Shekhawat*/
 
 /*creating new DB*/
 create database scd_db;
 
 /*ETL_Job Table Creation*/
CREATE TABLE scd_db.ETL_Job  (
  `Job_ID` int NOT NULL,
  `Job_Name` varchar(255) NULL,
  `Table_Name` varchar(255) NULL,
  `Schedule` varchar(255) NULL,
  `Created_by` varchar(255) NULL,
  `Created_Date` datetime NULL,
  PRIMARY KEY (`Job_ID`)
);
 
 /*ETL_Job_Log Table Creation*/
CREATE TABLE scd_db.ETL_Job_Log  (
  `Job_Log_ID` int NOT NULL AUTO_INCREMENT,
  `Job_ID` int NULL,
  `Job_Status` varchar(255) NULL,
  `Created_by` varchar(255) NULL,
  `Created_Date` datetime NULL,
  PRIMARY KEY (`Job_Log_ID`)
);
 
 /*ProductCostHistorySCD Table Creation*/
CREATE TABLE scd_db.ProductCostHistorySCD  (
  `SCD_SK` int NOT NULL AUTO_INCREMENT,
  `ProductID` int NULL,
  `ProductName` varchar(1000) NULL,
  `StandardCost` decimal(20, 10) NULL,
  `SCD_Start` datetime NULL,
  `SCD_End` datetime NULL,
  `SCD_Version` int NULL,
  `SCD_Active` int NULL,
  `DI_Job_ProcessID` varchar(255) NULL,
  `DI_CreatedDate` date NULL,
  PRIMARY KEY (`SCD_SK`)
);
 
/*ProductPriceHistorySCD Table Creation*/ 
CREATE TABLE scd_db.ProductPriceHistorySCD  (
  `SCD_SK` int NOT NULL AUTO_INCREMENT,
  `ProductID` int NULL,
  `ProductName` varchar(255) NULL,
  `ListPrice` decimal(20, 10) NULL,
  `SCD_Start` datetime NULL,
  `SCD_End` datetime NULL,
  `SCD_Version` int NULL,
  `SCD_Active` int NULL,
  `DI_Job_ProcessID` varchar(255) NULL,
  `DI_CreatedDate` date NULL,
  PRIMARY KEY (`SCD_SK`)
);

/*Adding Foreign Key Constraint*/ 
ALTER TABLE scd_db.ETL_Job_Log ADD FOREIGN KEY (`Job_ID`) REFERENCES scd_db.ETL_Job (`Job_ID`);

/*Script to insert rows into ETL_JOB*/
Insert into scd_db.ETL_Job values (1,'ADW_Load_Product_Cost_Hist_SCD','ProductCostHistorySCD','Daily',CURRENT_USER(),NOW());
Insert into scd_db.ETL_Job values (2,'ADW_Load_Product_Price_Hist_SCD','ProductPriceHistorySCD','Daily',CURRENT_USER(),NOW());
