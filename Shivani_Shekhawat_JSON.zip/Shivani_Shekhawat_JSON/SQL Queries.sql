use jsloading;
CREATE TABLE Actors_Dim (
	Actor_SK INT NOT NULL auto_increment,
    Actors_ID INT NULL, -- You may adjust the ID type as needed
    name VARCHAR(255), -- Assuming ActorName is the name of the actor
    BirthName VARCHAR(255), -- Assuming BirthName is the birth name of the actor
    BirthDate DATE, -- Assuming BirthDate is the birthdate of the actor
    BirthPlace VARCHAR(255), -- Assuming BirthPlace is the birthplace of the actor
	SCD_Start datetime NULL,
    SCD_End datetime NULL,
    SCD_Version int NULL,
    SCD_Active int NULL,
    DI_Workflow_FileName VARCHAR(255), -- Assuming FileName is the name of the file associated with the actor
    DI_Created_Date TIMESTAMP, -- Assuming DI_Created_Date is the creation date of the record
	DI_Workflow_ProcessID varchar(255) NULL,
    PRIMARY KEY(Actor_SK)
);
 select * from jsloading.Actors_Dim;
CREATE TABLE Directors_Dim (
	Director_SK int NOT NULL AUTO_INCREMENT,
    Directors_ID INT NULL, -- You may adjust the ID type as needed
    name VARCHAR(255), -- Assuming ActorName is the name of the actor
    BirthName VARCHAR(255), -- Assuming BirthName is the birth name of the actor
    BirthDate DATE, -- Assuming BirthDate is the birthdate of the actor
    BirthPlace VARCHAR(255), -- Assuming BirthPlace is the birthplace of the actor
	SCD_Start datetime NULL,
    SCD_End datetime NULL,
    SCD_Version int NULL,
    SCD_Active int NULL,
    DI_Workflow_FileName VARCHAR(255), -- Assuming FileName is the name of the file associated with the actor
    DI_Created_Date TIMESTAMP, -- Assuming DI_Created_Date is the creation date of the record
    DI_Workflow_ProcessID varchar(255) NULL,
    PRIMARY KEY(Director_SK)
);
 
CREATE TABLE Writer_Dim (
    Writer_SK INT AUTO_INCREMENT PRIMARY KEY, -- You may adjust the ID type as needed
    Writer_name VARCHAR(255), -- Assuming ActorName is the name of the actor
    DI_Workflow_FileName VARCHAR(255), -- Assuming FileName is the name of the file associated with the actor
    DI_Created_Date TIMESTAMP, -- Assuming DI_Created_Date is the creation date of the record
    DI_Workflow_ProcessID varchar(255) NULL
    );
CREATE TABLE Categories_Dim (
    Category_SK INT AUTO_INCREMENT PRIMARY KEY, -- You may adjust the ID type as needed
    Category_name VARCHAR(255), -- Assuming ActorName is the name of the actor
    DI_Workflow_FileName VARCHAR(255), -- Assuming FileName is the name of the file associated with the actor
    DI_Created_Date TIMESTAMP, -- Assuming DI_Created_Date is the creation date of the record
    DI_Workflow_ProcessID varchar(255) NULL
    );