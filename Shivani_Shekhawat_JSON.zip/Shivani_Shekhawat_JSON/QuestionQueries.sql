/*Query 1*/
SELECT f.Category_SK, c.Category_name, f.name AS MovieName,
 COUNT(DISTINCT w.Writer_SK) AS WriterCnt,
 COUNT(DISTINCT a.Actor_SK) AS ActorCnt
FROM gen_fact_data f
LEFT JOIN Writer_Dim w ON f.Writer_SK = w.Writer_SK
LEFT JOIN actors_dim a ON f.Actor_SK = a.Actor_SK
LEFT JOIN Categories_Dim c ON f.Category_SK = c.Category_SK
GROUP BY f.Category_SK,c.Category_name, f.name
HAVING COUNT(DISTINCT f.Writer_SK) > 4 AND COUNT(DISTINCT f.Actor_SK) > 3;

/*Query 2*/
SELECT DISTINCT (f.year) AS ReleaseYear, f.name AS MovieName
FROM gen_fact_data f
ORDER BY (f.year);