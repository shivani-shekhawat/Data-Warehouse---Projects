CREATE TABLE `default`.`Audit`  (
  `Audit_ID` int NOT NULL,
  `DI_CreatedDate` datetime NULL,
  `DI_WorkflowFileName` varchar(255) NULL,
  `DI_Workflow_ProcessID` int NULL,
  PRIMARY KEY (`Audit_ID`)
);

CREATE TABLE `default`.`DimBusiness`  (
  `Business_SK` int NOT NULL,
  `Business_ID` varchar(255) NOT NULL,
  `Facility Name` varchar(255) NULL,
  `Address` varchar(255) NULL,
  `City` varchar(255) NULL,
  `ZipCode` int NULL,
  `Phone Number` bigint NULL,
  `DI_CreatedDate` datetime NULL,
  `DI_WorkflowFileName` varchar(255) NULL,
  `DI_Workflow_ProcessID` int NULL,
  `Longitude` numeric NULL,
  `Latitude` numeric NULL,
  PRIMARY KEY (`Business_SK`)
);

CREATE TABLE `default`.`DimDate`  (
  `Date_SK` date NOT NULL,
  `DayNum` int NULL,
  `MonthNum` int NULL,
  `YearNum` int NULL,
  `IsWeekend` varchar(255) NULL,
  `QuaterNum` int NULL,
  `WeekdayNum` int NULL,
  `DI_CreatedDate` datetime NULL,
  `DI_WorkflowFileName` varchar(255) NULL,
  `DI_Workflow_ProcessID` int NULL,
  PRIMARY KEY (`Date_SK`)
);

CREATE TABLE `default`.`DimInspectionType`  (
  `Inspection_Type_SK` integer NOT NULL,
  `Inspection_Type` varchar(100) NULL,
  `DI_CreatedDate` datetime NULL,
  `DI_WorkflowFileName` varchar(255) NULL,
  `DI_Workflow_ProcessID` int NULL,
  PRIMARY KEY (`Inspection_Type_SK`)
);

CREATE TABLE `default`.`DimViolation`  (
  `Violation_SK` int NOT NULL,
  `ViolationCodes` varchar(1000) NULL,
  `ViolationDescriptions` varchar(2000) NULL,
  `ViolationCategory` varchar(255) NULL,
  `DI_CreatedDate` datetime NULL,
  `DI_WorkflowFileName` varchar(255) NULL,
  `DI_Workflow_ProcessID` varchar(255) NULL,
  PRIMARY KEY (`Violation_SK`)
);

CREATE TABLE `default`.`Fact_Violation`  (
  `ViolationFct_ID` int NOT NULL,
  `Inspection_FK` varchar(255) NULL,
  `Violation_Cat_FK` varchar(255) NULL,
  `Violation_Score` varchar(255) NULL,
  `Violation_FK` varchar(255) NULL,
  `DI_CreatedDate` datetime NULL,
  `DI_WorkflowFileName` varchar(255) NULL,
  `DI_Workflow_ProcessID` int NULL,
  PRIMARY KEY (`ViolationFct_ID`)
);

CREATE TABLE `default`.`Insp_Vio_Fact`  (
  `Insp_Vio_SK` varchar(255) NOT NULL,
  `Inspection_ID` int NULL,
  `Business_FK` varchar(255) NULL,
  `Date_FK` datetime NULL,
  `Inspection_Type_FK` varchar(255) NULL,
  `Violation_FK` varchar(255) NULL,
  `Inspection_Result` varchar(255) NULL,
  `Violation_Score` int UNSIGNED NULL,
  `DI_CreatedDate` datetime NULL,
  `DI_WorkflowFileName` varchar(255) NULL,
  `DI_Workflow_ProcessID` int NULL
);

ALTER TABLE `default`.`Fact_Violation` ADD CONSTRAINT `Violation_Cat_FK` FOREIGN KEY (`Violation_Cat_FK`) REFERENCES `default`.`DimViolationCategory` (`Violation_Cat_SK`);
ALTER TABLE `default`.`Fact_Violation` ADD CONSTRAINT `Violation_FK` FOREIGN KEY (`Violation_FK`) REFERENCES `default`.`DimViolation` (`Violation_SK`);
ALTER TABLE `default`.`Insp_Vio_Fact` ADD CONSTRAINT `Date_FK` FOREIGN KEY (`Date_FK`) REFERENCES `default`.`DimDate` (`Date`);
ALTER TABLE `default`.`Insp_Vio_Fact` ADD CONSTRAINT `Business_FK` FOREIGN KEY (`Business_FK`) REFERENCES `default`.`DimBusiness` (`Business_SK`);
ALTER TABLE `default`.`Insp_Vio_Fact` ADD CONSTRAINT `Inspection_Type_FK` FOREIGN KEY (`Inspection_Type_FK`) REFERENCES `default`.`DimInspectionType` (`Inspection_Type_SK`);
ALTER TABLE `default`.`Insp_Vio_Fact` ADD CONSTRAINT `Violation_FK` FOREIGN KEY (`Violation_FK`) REFERENCES `default`.`DimViolation` (`Violation_SK`);

